import re
file_name = input("Enter file name:")
file = open(file_name, "r")

seq = ""
anot = []
flag = True 

for line in file:
            if re.match(r'^//', line):
                print("end found")
                break
            elif re.match(r'ORIGIN', line):
                flag = False
                continue

            elif flag:
                anot.append(line)

            else:
                seq = seq + line
file.close()
print(anot)               

print(seq)
                
newseq = re.sub(r'\s+', '', seq)
newseq = re.sub(r'\d', '', newseq)
newseq = newseq.upper()

print(newseq)


for i in anot:
    if re.search(r'CDS', i):
        cds = re.split(r'\s+', i)
        print(cds)

        position = re.split(r'\.\.', cds[2])
        print(position)

        first_pos = int(position[0])
        last_pos = int(position[1])
        first_pos = first_pos - 1
        cds_seq = newseq[first_pos:last_pos]

        print(cds_seq)

        
definition = ""
version = ""

for i in anot:
    if i.startswith("DEFINITION"):
        definition = i.split("DEFINITION")[1].strip()
    elif i.startswith("VERSION"):
        version = i.split("VERSION")[1].strip()

fasta_header = f">{version} {definition}"

'''below code will automatically create a .fasta file and 
by using "w" we can add the defination line and the sequence 
to the new fasta format file'''

output_file = file_name.split('.')[0] + "_s.fasta"
with open(output_file, "w") as fasta:
    fasta.write(fasta_header + "\n")

    for i in range(0, len(newseq), 60):
        fasta.write(newseq[i:i+60] + "\n")

print(f"\nFASTA file '{output_file}' created successfully.")
print("Header:", fasta_header)   
    
